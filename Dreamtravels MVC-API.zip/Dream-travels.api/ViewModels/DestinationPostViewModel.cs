using System.ComponentModel.DataAnnotations;

namespace Dream_travels.api.ViewModels
{
    public class DestinationPostViewModel
    {
        [Required(ErrorMessage = "Namn måste anges")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Semestertyp måste anges")]
        public string VacationType { get; set; }

        [Required(ErrorMessage = "Land måste anges")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Land måste anges")]
        public string Continent { get; set; }

        [Required(ErrorMessage = "Pris måste anges")]
        public int Pricing { get; set; }

        [Required(ErrorMessage = "Beskrivning måste anges")]
        public string Description { get; set; }
        
    }
}