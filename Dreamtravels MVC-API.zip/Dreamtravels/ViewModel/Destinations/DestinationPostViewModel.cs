using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Dreamtravels.ViewModel.Destinations
{
    public class DestinationPostViewModel : BaseViewModel
   {
       
       [Required(ErrorMessage = "*Kontinent måste anges*")]
       [DisplayName("Kontinent")]
       public string Continent { get; set; }

       [Required(ErrorMessage = "*Land måste anges*")]
       [DisplayName("Land")]
       public string Country { get; set; }

       [Required(ErrorMessage = "*Typ av resemål måste anges*")]
       [DisplayName("Resetyp")]
       public string VacationType { get; set; }

       [Required(ErrorMessage = "Pris måste anges")]
       [DisplayName("Pris")]
       public int Pricing { get; set; }
       public string Description { get; set; }
   }
}
