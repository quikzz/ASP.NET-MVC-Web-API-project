using System.ComponentModel.DataAnnotations.Schema;

namespace Dream_travels.api.Entities
{
    public class Destination 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Continent { get; set; }
        public string Country { get; set; }
        public string VacationType { get; set; }
        public int Pricing { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
    }
}