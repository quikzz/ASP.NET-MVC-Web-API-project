namespace Dreamtravels.ViewModel.Destinations
{
    public class DestinationDetailsViewModel : BaseViewModel
    {
         public string Continent { get; set; }
        public string Country { get; set; }
        public string Vacationtype { get; set; }
        public string ImageUrl { get; set; }
        public int Pricing { get; set; }
        public string Description { get; set; }
    
    }
}