using Dream_travels.api.Data;
using Dream_travels.api.Entities;
using Dream_travels.api.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Dream_travels.api.Controllers
{
    [ApiController]
    [Route("api/v1/destinations")]
    public class DestinationsController : ControllerBase
    {
        private readonly DreamTravelsContext _context;
        private readonly string _imageBaseUrl;
        private readonly IConfiguration _config;

        public DestinationsController(DreamTravelsContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
            _imageBaseUrl = _config.GetSection("apiImageUrl").Value;
        }


        // Listar all information kring resemålet.
        [HttpGet()]
        public async Task<IActionResult>ListAll()
        {
            var result = await _context.Destinations
            .Select(v => new{
                Id = v.Id,
                Name = v.Name,
                Country = v.Country,
                Continent = v.Continent,
                VacationType = v.VacationType,
                Pricing = v.Pricing,
                Description = v.Description,
                ImageUrl = _imageBaseUrl + v.ImageUrl ?? "imagenotfound.jpg"
                
            })
            .ToListAsync();

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id){

            var result = await _context.Destinations
            .Select(v => new
            {
                Id = v.Id,
                Name = v.Name,
                Country = v.Country,
                Continent = v.Continent,
                VacationType = v.VacationType,
                Pricing = v.Pricing,
                Description = v.Description,
                ImageUrl = _imageBaseUrl + v.ImageUrl ?? "imagenotfound.jpg"
                
            })
            .SingleOrDefaultAsync(c => c.Id == id);

            return Ok(result);
        }
        
        [HttpPost]
        public async Task<IActionResult>Add(DestinationPostViewModel destination){

             if (!ModelState.IsValid)
            {
                return BadRequest("All information är inte med i anropet");
            }

            var destinationToAdd = new Destination
            {
                
                Name = destination.Name,
                Country = destination.Country,
                Continent = destination.Continent,
                VacationType = destination.VacationType,
                Pricing = destination.Pricing,
                Description = destination.Description,
                ImageUrl = "imagenotfound.jpg",
            };

            try
            {
                await _context.Destinations.AddAsync(destinationToAdd);

                if (await _context.SaveChangesAsync() > 0)
                {
                    // return StatusCode(201);
                    return CreatedAtAction(nameof(GetById), new { id = destinationToAdd.Id },
                    new
                    {
                        Id = destinationToAdd.Id,
                        Name = destinationToAdd.Name,
                        Country = destinationToAdd.Country,
                        Continent = destinationToAdd.Continent,
                        VacationType = destinationToAdd.VacationType,
                        Pricing = destinationToAdd.Pricing,
                        Description = destinationToAdd.Description,
                    });
                }

                return StatusCode(500, "Internal Server Error");
            }
            catch (Exception ex)
            {
                // loggning till en databas som hanterar debug information...
                Console.WriteLine(ex.Message);
                return StatusCode(500, "Internal Server Error");
            }
        }
    }  
}
