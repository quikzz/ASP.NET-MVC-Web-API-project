using Dream_travels.api.Entities;
using Microsoft.EntityFrameworkCore;

namespace Dream_travels.api.Data
{
    public class DreamTravelsContext : DbContext
    {
        public DbSet<Destination> Destinations { get; set; }
        public DreamTravelsContext(DbContextOptions options) : base(options){ }
    }
}