using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Dreamtravels.ViewModel
{
    public class BaseViewModel
    {

        public int Id { get; set; }
        
        [Required(ErrorMessage = "Namn måste anges")]
        [DisplayName("Namn")]
        public string Name { get; set; }
    }
}