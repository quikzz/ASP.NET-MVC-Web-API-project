using System.Text.Json;
using Dream_travels.api.Entities;

namespace Dream_travels.api.Data
{
    public static class SeedData
    {
        public static async Task LoadDestinationData(DreamTravelsContext context)
        {
            // Steg 1.
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            if (context.Destinations.Any()) return;

            var json = System.IO.File.ReadAllText("Data/json/destinations.json");

            // Steg 4. Omvandla json objekten till en lista av VehicleModel objekt...
            var destinations = JsonSerializer.Deserialize<List<Destination>>(json, options);

            // Steg 5. Skicka listan med VehicleModel objekt till databasen...
            if (destinations is not null && destinations.Count > 0)
            {
                await context.Destinations.AddRangeAsync(destinations);
                await context.SaveChangesAsync();
            }
        }
    }
}
