﻿using Microsoft.AspNetCore.Mvc;

namespace Dreamtravels.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View("Start");
    }

}
