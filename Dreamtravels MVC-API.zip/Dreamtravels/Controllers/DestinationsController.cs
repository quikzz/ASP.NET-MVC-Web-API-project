using System.Text;
using System.Text.Json;
using Dreamtravels.Models;
using Dreamtravels.ViewModel.Destinations;
using Microsoft.AspNetCore.Mvc;

[Route("Destinations")]


public class DestinationsController : Controller
{
   
   private readonly string _baseUrl;
   private readonly IHttpClientFactory _httpClient;
   private readonly JsonSerializerOptions _options;



   public DestinationsController(IConfiguration config, IHttpClientFactory httpClient)
   {
       
       _baseUrl = config.GetSection("apiSettings:baseUrl").Value;
       _httpClient = httpClient;
       _options = new JsonSerializerOptions{PropertyNameCaseInsensitive = true};

   }

   public async Task<IActionResult> Index()
   {


       using var client = _httpClient.CreateClient();
       var response = await client.GetAsync($"{_baseUrl}/destinations");


       if(!response.IsSuccessStatusCode)return Content("Oops här gick det snett");


       var json = await response.Content.ReadAsStringAsync();


       var destinations = JsonSerializer.Deserialize<IList<DestinationListViewModel>>(json, _options);


       return View(destinations);
   }


   [HttpGet("details/{id}")]
   public async Task<IActionResult> Details(int id)
   {
        using var client = _httpClient.CreateClient();
        var response = await client.GetAsync($"{_baseUrl}/destinations/{id}");

        if (!response.IsSuccessStatusCode) return Content("Oops det gick fel");

        var json = await response.Content.ReadAsStringAsync();

        var destination = JsonSerializer.Deserialize<DestinationDetailsViewModel>(json, _options);

        return View("Details", destination);
   }
    [HttpGet("Create")]
    public IActionResult Create()
    {
        var destination = new DestinationPostViewModel{};

        return View("Create", destination);
    }


  [HttpPost("Create")]
   public async Task<IActionResult> Create(DestinationPostViewModel destination)
   {
    var client = _httpClient.CreateClient();
    var response = await client.PostAsJsonAsync($"{_baseUrl}/destinations",destination);

    if (!response.IsSuccessStatusCode) return BadRequest("Ops något gick fel!");

    return RedirectToAction("Index");
   }
   
}
