

namespace Dreamtravels.Models
{
    public class DestinationModel 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }
        public string Continent { get; set; }
        public string VacationType { get; set; }
        public string Description { get; set; }
        public int Pricing { get; set; }
        public string ImageUrl { get; set; }
    }
}